package com.example.taxi_booking_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.taxi_booking_app.activities.authentication.LoginActivity;
import com.example.taxi_booking_app.activities.profile.ProfileSetupActivity;
import com.example.taxi_booking_app.activities.rides.RideListActivity;
import com.example.taxi_booking_app.adapters.RideAdapter;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RideAdapter rideAdapter;
    private Button logoutButton,profileView,mRides;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();
        logoutButton = findViewById(R.id.button);
        profileView=findViewById(R.id.profile);
        mRides=findViewById(R.id.rides);


        //Available rides
        mRides.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, RideListActivity.class));
        });


        //to view profile
        profileView.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, ProfileSetupActivity.class));
        });

        //logout button handle
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Sign out from FirebaseAuth
                mAuth.signOut();

                // Clear login state in SharedPreferences
                SharedPreferences sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean("logged_in", false);
                editor.apply();

                // Redirect to LoginActivity
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });

    }
}