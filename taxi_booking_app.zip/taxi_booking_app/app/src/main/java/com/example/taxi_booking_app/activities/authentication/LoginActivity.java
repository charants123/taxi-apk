package com.example.taxi_booking_app.activities.authentication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.taxi_booking_app.MainActivity;
import com.example.taxi_booking_app.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {

    EditText mEmail, mPassword;
    Button mLogin;
    FirebaseAuth firebaseAuth;
    TextView mSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Check if user is already logged in
        SharedPreferences sharedPreferences1 = getSharedPreferences("user_prefs", MODE_PRIVATE);
        boolean value = sharedPreferences1.getBoolean("logged_in", false);

        if (value) {
            startActivity(new Intent(LoginActivity.this, MainActivity.class));
            finish(); // Finish LoginActivity so it doesn't remain in the back stack
            return;
        }
        setContentView(R.layout.activity_login);

        // Initializing Views
        mEmail = findViewById(R.id.email);
        mPassword = findViewById(R.id.password);
        mLogin = findViewById(R.id.login_button);
        firebaseAuth = FirebaseAuth.getInstance();
        mSignUp = findViewById(R.id.signUp);

        mSignUp.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, SignUpActivity.class));
        });

        // User clicks Login button
        mLogin.setOnClickListener(v -> {
            String email = mEmail.getText().toString().trim();
            String password = mPassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Fields cannot be empty.", Toast.LENGTH_SHORT).show();
                return;
            }

            firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    FirebaseUser user = firebaseAuth.getCurrentUser();
                    if (user != null) {

                        // Store login state using SharedPreferences
                        SharedPreferences.Editor editor = sharedPreferences1.edit();
                        editor.putBoolean("logged_in", true);
                        editor.apply();
                        startActivity(new Intent(LoginActivity.this, MainActivity.class));
                        finish();
                    } else{
                        Toast.makeText(LoginActivity.this, "verify credentials.", Toast.LENGTH_SHORT).show();

                    }
                }
                else {
                    Toast.makeText(LoginActivity.this, "Login failed. Please try again.", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }
}
