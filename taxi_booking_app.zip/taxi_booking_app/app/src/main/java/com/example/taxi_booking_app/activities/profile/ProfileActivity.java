package com.example.taxi_booking_app.activities.profile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import com.example.taxi_booking_app.R;

public class ProfileActivity extends AppCompatActivity {

    private TextView tvName, tvEmail, tvPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);
        tvPhone = findViewById(R.id.tvPhone);

        displayProfileInfo();
    }

    private void displayProfileInfo() {
        // Retrieve profile information from SharedPreferences
        SharedPreferences preferences = getSharedPreferences("profile", MODE_PRIVATE);
        String name = preferences.getString("name", "");
        String email = preferences.getString("email", "");
        String phone = preferences.getString("phone", "");

        // Display profile information
        tvName.setText(name);
        tvEmail.setText(email);
        tvPhone.setText(phone);
    }
}