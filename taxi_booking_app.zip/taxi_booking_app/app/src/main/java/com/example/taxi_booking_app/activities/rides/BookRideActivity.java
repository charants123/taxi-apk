package com.example.taxi_booking_app.activities.rides;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.taxi_booking_app.R;
import com.example.taxi_booking_app.database.AppDatabase;
import com.example.taxi_booking_app.model.Ride;
import com.example.taxi_booking_app.model.RideDao;

import java.util.ArrayList;
import java.util.List;

public class BookRideActivity extends AppCompatActivity {
    private ListView rideDetailsListView;
    private Button confirmPaymentButton, viewBookingButton, updateBookingButton, cancelPaymentButton;
    private RideDao rideDao;
    private List<Ride> rideList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_ride);
        rideDetailsListView = findViewById(R.id.rideDetailsTextView);
        confirmPaymentButton = findViewById(R.id.confirmPaymentButton);
        viewBookingButton = findViewById(R.id.viewBookingButton);
        updateBookingButton = findViewById(R.id.updateBookingButton);
        cancelPaymentButton = findViewById(R.id.cancel_payment);

        // Initialize Room database and DAO
        AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "ride-database").allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();
        rideDao = db.rideDao();

        // Fetching rides when activity starts
        viewBookingButton.setOnClickListener(v -> {
            new GetRidesTask().execute();
        });

        //  Inserting a ride
        confirmPaymentButton.setOnClickListener(v -> {
            Ride ride = new Ride("John Doe", "Toyota Camry", "ABC123", 25.0);
            new InsertRideTask().execute(ride);
        });

        //  Updating a ride (first ride in the list)
        updateBookingButton.setOnClickListener(v -> {
            if (rideList != null && !rideList.isEmpty()) {
                Ride rideToUpdate = rideList.get(0);
                rideToUpdate.setDriverName("Updated Driver Name");
                new UpdateRideTask().execute(rideToUpdate);
            }
        });

        //  Deleting all rides
        cancelPaymentButton.setOnClickListener(v -> {
            new DeleteAllRidesTask().execute();
        });
    }

    // AsyncTask to insert a ride
    private class InsertRideTask extends AsyncTask<Ride, Void, Void> {
        @Override
        protected Void doInBackground(Ride... rides) {
            rideDao.insert(rides[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            Toast.makeText(BookRideActivity.this, "Ride inserted successfully", Toast.LENGTH_SHORT).show();
        }
    }

    // AsyncTask to fetch all rides
    private class GetRidesTask extends AsyncTask<Void, Void, List<Ride>> {
        @Override
        protected List<Ride> doInBackground(Void... voids) {
            return rideDao.getRides();
        }

        @Override
        protected void onPostExecute(List<Ride> rides) {
            rideList = rides;
            displayRides(rideList);
        }
    }

    // AsyncTask to update a ride
    private class UpdateRideTask extends AsyncTask<Ride, Void, Void> {
        @Override
        protected Void doInBackground(Ride... rides) {
            rideDao.update(rides[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            Toast.makeText(BookRideActivity.this, "Ride updated successfully", Toast.LENGTH_SHORT).show();
        }
    }

    // AsyncTask to delete all rides
    private class DeleteAllRidesTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            rideDao.deleteAll();
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            Toast.makeText(BookRideActivity.this, "All rides deleted successfully", Toast.LENGTH_SHORT).show();
        }
    }

    // Helper method to display rides in ListView
    private void displayRides(List<Ride> rides) {
        List<String> rideInfoList = new ArrayList<>();
        for (Ride ride : rides) {
            String info = "ID: " + ride.getId() + "\n" +
                    "Driver: " + ride.getDriverName() + "\n" +
                    "Car Model: " + ride.getCarModel() + "\n" +
                    "License Plate: " + ride.getLicensePlate() + "\n" +
                    "Fare: $" + ride.getFare();
            rideInfoList.add(info);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, rideInfoList);
        rideDetailsListView.setAdapter(adapter);
    }
}