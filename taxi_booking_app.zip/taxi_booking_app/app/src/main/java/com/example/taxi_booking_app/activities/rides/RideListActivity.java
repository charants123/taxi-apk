package com.example.taxi_booking_app.activities.rides;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;


import com.example.taxi_booking_app.R;
import com.example.taxi_booking_app.adapters.RideAdapter;
import com.example.taxi_booking_app.model.Ride;

import java.util.ArrayList;
import java.util.List;

public class RideListActivity extends AppCompatActivity implements RideAdapter.OnRideClickListener {

    private RecyclerView recyclerView;
    private RideAdapter rideAdapter;
    private List<Ride> rideList;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ride_list);


        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        rideList = new ArrayList<>();
        // Add dummy data
        rideList.add(new Ride( "A", "Toyota Camry", "ABC123", 25.0));
        rideList.add(new Ride("B", "Honda ", "XYZ789", 30.0));
        rideList.add(new Ride( "C", "Benz", "ABC423", 35.0));
        rideList.add(new Ride( "D", "Audi", "XYZ589", 40.0));
        rideList.add(new Ride( "E", "porshe", "ABC723", 45.0));
        rideList.add(new Ride( "F", "Bugati", "XYZ1789", 50.0));
        rideList.add(new Ride( "G", "toyota", "ABC1423", 55.0));
        rideList.add(new Ride( "H", "Bmw", "XYZ7839", 60.0));
        rideList.add(new Ride( "I", "jaguar", "ABC1223", 65.0));
        rideList.add(new Ride( "J", "tata", "XYZ6789", 70.0));
        rideList.add(new Ride( "K", "rollsRoyce", "ABC1723", 75.0));
        rideList.add(new Ride( "L", "maruti", "XYZ7889", 80.0));
        rideList.add(new Ride( "M", "kia", "ABC1823", 85.0));
        rideList.add(new Ride( "N", "mariti", "XYZ7989", 90.0));
        // Add more rides as needed

        rideAdapter = new RideAdapter(rideList, this);
        recyclerView.setAdapter(rideAdapter);
    }

    @Override
    public void onRideClick(Ride ride) {
        // Handle ride booking
        Intent intent = new Intent(RideListActivity.this, BookRideActivity.class);
        intent.putExtra("rideId", ride.getId());
        intent.putExtra("driver_name",ride.getDriverName());
        intent.putExtra("car_model",ride.getCarModel());
        intent.putExtra("licence_plate",ride.getLicensePlate());
        intent.putExtra("fare",ride.getFare());
        startActivity(intent);
        Toast.makeText(this, "Selected Ride: " + ride.getDriverName(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDeleteClick(Ride ride) {
        Toast.makeText(this,"please confirm booking",Toast.LENGTH_SHORT).show();
    }


}