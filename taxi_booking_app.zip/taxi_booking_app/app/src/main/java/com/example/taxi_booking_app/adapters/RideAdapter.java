package com.example.taxi_booking_app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.taxi_booking_app.R;
import com.example.taxi_booking_app.model.Ride;

import java.util.List;

public class RideAdapter extends RecyclerView.Adapter<RideAdapter.RideViewHolder> {

    private List<Ride> rideList;
    private OnRideClickListener listener;

    public interface OnRideClickListener {
        void onRideClick(Ride ride);
        void onDeleteClick(Ride ride);
    }

    public RideAdapter(List<Ride> rideList, OnRideClickListener listener) {
        this.rideList = rideList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public RideViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ride, parent, false);
        return new RideViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RideViewHolder holder, int position) {
        Ride ride = rideList.get(position);
        holder.driverNameTextView.setText(ride.getDriverName());
        holder.carModelTextView.setText(ride.getCarModel());
        holder.licensePlateTextView.setText(ride.getLicensePlate());
        holder.fareTextView.setText(String.valueOf(ride.getFare()));
        holder.bookButton.setOnClickListener(v -> listener.onRideClick(ride));
        holder.cancelButton.setOnClickListener(v -> listener.onDeleteClick(ride));
    }

    @Override
    public int getItemCount() {
        return rideList.size();
    }

    public static class RideViewHolder extends RecyclerView.ViewHolder {
        TextView driverNameTextView, carModelTextView, licensePlateTextView, fareTextView;
        Button bookButton,cancelButton;

        public RideViewHolder(@NonNull View itemView) {
            super(itemView);
            driverNameTextView = itemView.findViewById(R.id.driverNameTextView);
            carModelTextView = itemView.findViewById(R.id.carModelTextView);
            licensePlateTextView = itemView.findViewById(R.id.licensePlateTextView);
            fareTextView = itemView.findViewById(R.id.fareTextView);
            bookButton = itemView.findViewById(R.id.bookButton);
            cancelButton=itemView.findViewById(R.id.deleteBookingButton);
        }
    }
}
