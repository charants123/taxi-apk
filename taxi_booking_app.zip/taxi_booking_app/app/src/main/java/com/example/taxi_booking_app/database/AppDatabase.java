package com.example.taxi_booking_app.database;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.taxi_booking_app.model.Ride;
import com.example.taxi_booking_app.model.RideDao;

@Database(entities={Ride.class},version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract RideDao rideDao();
}