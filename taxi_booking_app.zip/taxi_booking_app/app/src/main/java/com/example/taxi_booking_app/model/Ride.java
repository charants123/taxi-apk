package com.example.taxi_booking_app.model;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Ride {
    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "driver_name")
    private String driverName;

    @ColumnInfo(name = "car_model")
    private String carModel;

    @Override
    public String toString() {
        return "Ride" +
                "  id=" + id +
                ", driverName='" + driverName + "\n" +
                ", carModel='" + carModel + "\n" +
                ", licensePlate='" + licensePlate + "\n" +
                ", fare=" + fare;
    }

    @ColumnInfo(name = "license_plate")
    private String licensePlate;

    @ColumnInfo(name = "fare")
    private double fare;

    public Ride(String driverName, String carModel, String licensePlate, double fare) {
        this.driverName = driverName;
        this.carModel = carModel;
        this.licensePlate = licensePlate;
        this.fare = fare;
    }

    public int getId() {
        return id;
    }

    public String getDriverName() {
        return driverName;
    }

    public String getCarModel() {
        return carModel;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public double getFare() {
        return fare;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public void setFare(double fare) {
        this.fare = fare;
    }
}

