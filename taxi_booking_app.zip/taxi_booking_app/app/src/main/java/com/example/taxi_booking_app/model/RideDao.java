package com.example.taxi_booking_app.model;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface RideDao {
    @Insert
    public void insert(Ride ride);

    @Query("delete from Ride where id= :rideId")
    public  void delete(int rideId);

    @Query("select * from Ride")
    public List<Ride> getRides();

    @Query("delete from Ride")
    public void deleteAll();

    @Update
    void update(Ride ride);

    @Query("SELECT * FROM Ride WHERE id = :rideId")
    Ride getRideById(int rideId);

}
